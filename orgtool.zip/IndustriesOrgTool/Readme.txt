
## Production
```bash
docker-compose up --build
```
## Development (auto rebuild on local code changes)
```bash
docker-compose -f docker-compose.dev.yaml up --build 
```