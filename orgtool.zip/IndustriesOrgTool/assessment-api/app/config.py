from pydantic import BaseSettings


class Settings(BaseSettings):
    secret_key: str
    algorithm: str
    ACCESS_TOKEN_EXPIRE_MINUTES: int
    REDIS_STRICT_SSL: str
    REDIS_URL: str
    REDIS_TLS_URL:str

    class Config:
        env_file = ".env"


settings = Settings()


