import asyncio
from redis import asyncio as aioredis
import json
from .config import settings
REDIS_URL = settings.REDIS_URL
redis = aioredis.from_url(REDIS_URL, decode_responses=True)
TWENTY_MINUTES = 1200

async def get_cache(keys):
    current_hour_cache_key = keys
    current_hour_stats = await redis.get(current_hour_cache_key)

    if current_hour_stats:
        return json.loads(current_hour_stats)


async def set_cache(data):
    await redis.set(
        data['methodname'],
        json.dumps(data),
        ex=TWENTY_MINUTES,
    )
    