from pydantic import BaseModel, EmailStr
from datetime import datetime
from typing import Optional


class userLogin(BaseModel):
    email: str
    password: str
    securityToken: str
    customerName: str
    domain:str
    useSecurityToken: bool


class internalUserLogin(BaseModel):
    session_id: str
    sf_instance: str


class Token(BaseModel):
    access_token: str
    token_type: str


class TokenData(BaseModel):
    session_id: str
    sf_instance: str
