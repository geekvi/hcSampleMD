from fastapi import FastAPI, Body, Response, status, HTTPException, Depends, APIRouter
from simple_salesforce import Salesforce, SalesforceLogin, SFType
import json
from ... import oauth2
from multiprocessing.dummy import Pool as ThreadPool
from requests import *
from ...redis_function import get_cache, set_cache
import json

router = APIRouter(
    prefix="/getIntegrationProcedure",
    tags=['IntegrationProcedure']
)


@router.get("/")
async def get_allintegrationprocedure(get_current_user: dict = Depends(oauth2.get_current_user)):
    sf = Salesforce(instance_url="https://"+get_current_user['sf_instance'],
                    session_id=get_current_user['session_id'])
    getAllintegrationprocedureQuery = "SELECT Id,ElementTypeComponentMapping,IsActive,IsOmniScriptEmbeddable,IsWebCompEnabled,Language,Name,SubType,Type FROM OmniProcess WHERE OmniProcessType = 'Integration Procedure' AND IsActive = true"
    elements_not_following_prac_count = 0
    elements_following_prac_count = 0       
    try:
        cached_data = await get_cache("IPCore"+sf.session_id)
        #print(f"cached data {cached_data}")
        if cached_data is not None:
            allActiveIntegrationProcedureRecords = cached_data
        else:  
            allActiveIntegrationProcedureRecords = sf.query(
                getAllintegrationprocedureQuery)
            for x in allActiveIntegrationProcedureRecords:
                if x == 'records':
                    for record in range(len(allActiveIntegrationProcedureRecords.get("records"))):
                        allActiveIntegrationProcedureRecords.get("records")[record]["resturl"]  =   "https://"+get_current_user['sf_instance']
                        allActiveIntegrationProcedureRecords.get("records")[record]["header"]  =  sf.headers
                        allActiveIntegrationProcedureRecords.get("records")[record]["sid"]  =  sf.session_id
            #Splitting records into chunks of two to do threading 
            split_range = list(chunks( allActiveIntegrationProcedureRecords.get("records"), 1))
            pool = ThreadPool(len(split_range))
            final_result = []
            test = pool.map(splitTransaction, split_range)
            #print(f"test {test}")  
            #The threaded data comes back in array of max 2 objects here since we are sending only 2 a time. We do some post processing to get the final count. 
            for i in range(len(test)):
                if len(test[i]) > 0:
                    for y in range(len(test[i])):
                        final_result.append(test[i][y])
            for item in final_result:
                if item["Follows Good Practice"] == "No":
                    elements_not_following_prac_count += 1
                else:
                    elements_following_prac_count += 1           
                del item["header"]
                del item["resturl"]
                del item["sid"]                      
                                                                                        
            allActiveIntegrationProcedureRecords["records"] = final_result
            allActiveIntegrationProcedureRecords["size"] = len(final_result)
            allActiveIntegrationProcedureRecords["totalSize"] = len(final_result)
            allActiveIntegrationProcedureRecords['Elements following bad prac'] = elements_not_following_prac_count 
            allActiveIntegrationProcedureRecords['Elements following good prac'] = elements_following_prac_count

            pool.close()
            pool.join()          

    except Exception as e:
        print(e)

    allActiveIntegrationProcedureRecords['methodname'] = "IPCore"+sf.session_id   
    await set_cache(allActiveIntegrationProcedureRecords) 

    return allActiveIntegrationProcedureRecords


@router.get("/{Id}")
def get_integrationProcedure(Id, get_current_user: dict = Depends(oauth2.get_current_user)):
    sf = Salesforce(instance_url="https://"+get_current_user['sf_instance'],
                    session_id=get_current_user['session_id'])
    getintegrationprocedurebyIdQuery = "SELECT IsActive, Name, PropertySetConfig, SequenceNumber, Type FROM OmniProcessElement WHERE OmniProcessId = '" + \
        Id + "' AND IsActive = true ORDER BY SequenceNumber ASC NULLS FIRST"
    try:
        specificIntegrationProcedureRecords = sf.query(
            getintegrationprocedurebyIdQuery)
    except Exception as e:
        print(e)
    if specificIntegrationProcedureRecords:
        # Eventually this will be  moved to UI/JS. Just for urgent ORG review purpose
        for elm in specificIntegrationProcedureRecords['records']:
            if elm['Type'] == 'Response Action':
                responseActionPropConfig = json.loads(elm['PropertySetConfig'])
                elm['returnFullDataJSON'] = responseActionPropConfig['returnFullDataJSON']
                elm['returnOnlyAdditionalOutput'] = responseActionPropConfig['returnOnlyAdditionalOutput']
                elm['sendJSONPath'] = responseActionPropConfig['sendJSONPath']
                elm['goodOrBad'] = "Bad Practice" if responseActionPropConfig['returnFullDataJSON'] else (
                    "Good Practice" if responseActionPropConfig['returnOnlyAdditionalOutput'] else ("Good Practice" if responseActionPropConfig['sendJSONPath'] else "Bad Practice"))
    return specificIntegrationProcedureRecords

# The worker function
def splitTransaction(data):
    #print(f"here in pool data {data}")
    pooled_data = []
    for num in range(len(data)):
        sf = Salesforce(instance_url=data[num].get('resturl'),
                        session_id=data[num].get('sid'))
        getIPIdQuery = "SELECT IsActive, Name, PropertySetConfig, SequenceNumber, Type FROM OmniProcessElement WHERE OmniProcessId = '"  + data[num].get('Id') + "' AND IsActive = true ORDER BY SequenceNumber ASC NULLS FIRST"
        specificIPRecords = sf.query(getIPIdQuery)
        if len(specificIPRecords.get('records'))>0:
            #responseActionPropConfig = ''
            #print(f"elm['Type'] {specificIPRecords['records']['Type']}")
            data[num]['Follows Good Practice'] = "No" 
            for elm in specificIPRecords['records']:
                #print(f"elm['Type'] {elm['Type']}")
                if elm['Type'] == 'Response Action':            
                    responseActionPropConfig = json.loads(elm['PropertySetConfig'])
                    #print(f"responseActionPropConfig {responseActionPropConfig}")
                    if responseActionPropConfig['returnFullDataJSON']:
                        data[num]['Follows Good Practice'] = "No"
                    elif responseActionPropConfig['returnOnlyAdditionalOutput'] or len(responseActionPropConfig['sendJSONPath']) > 0:
                        data[num]['Follows Good Practice'] = "Yes"
            pooled_data.append(data[num])                  
    return pooled_data

def chunks(lst, n):
    """Yield successive n-sized chunks from lst."""
    for i in range(0, len(lst), n):
        yield lst[i:i + n]
