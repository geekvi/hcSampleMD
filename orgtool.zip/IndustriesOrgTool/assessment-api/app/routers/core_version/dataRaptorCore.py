from fastapi import FastAPI, Body, Response, status, HTTPException, Depends, APIRouter
from simple_salesforce import Salesforce, SalesforceLogin, SFType
from ... import oauth2
from multiprocessing.dummy import Pool as ThreadPool
from requests import *
from ...redis_function import get_cache, set_cache
import json

router = APIRouter(
    prefix="/getdataRaptor",
    tags=['DataRaptor']
)


@router.get("/")
async def get_dataRaptor(get_current_user: dict = Depends(oauth2.get_current_user)):
    sf = Salesforce(instance_url="https://"+get_current_user['sf_instance'],
                    session_id=get_current_user['session_id'])
    getAlldataraptorsQuery = "SELECT Name, Id, LastModifiedDate, Type, InputType, OutputType, Description FROM OmniDataTransform ORDER BY Name ASC NULLS FIRST LIMIT 200 OFFSET 0"
    elements_not_following_prac_count = 0
    elements_following_prac_count = 0 

    try:
        cached_data = await get_cache("DRCore"+sf.session_id)
        #print(f"cached data {cached_data}")
        if cached_data is not None:
            allActiveDataRaptorsRecords = cached_data                                     
        else:
            allActiveDataRaptorsRecords = sf.query(getAlldataraptorsQuery)
            test_range = []
            #print(f"len(allActiveDataRaptorsRecords.get('records')) {len(allActiveDataRaptorsRecords.get('records'))}")
            for record in allActiveDataRaptorsRecords.get('records'):
                record["resturl"]  =   "https://"+get_current_user['sf_instance']
                record["header"]  =  sf.headers
                record["sid"]  =  sf.session_id
                test_range.append(record)
                #Splitting records into chunks of two to do threading 
            #split_range = list(chunks( allActiveDataRaptorsRecords.get("records"), 1))
            print(f"split_range {len(test_range)}")
            pool = ThreadPool(len(test_range))
            final_result = []
            test = pool.map(splitTransaction, test_range)
            pool.close()
            pool.join()   
            #print(f"test {test}")  
            #The threaded data comes back in array of max 2 objects here since we are sending only 2 a time. We do some post processing to get the final count. 
            for i in range(len(test)):
                if len(test[i]) > 0:
                    for y in range(len(test[i])):
                        final_result.append(test[i][y])
            #print(f" final_result {final_result}")            
            for item in final_result:
                del item["header"]
                del item["resturl"]
                del item["sid"]                      
                if item["Type"] == "Extract" or item["Type"] == "Turbo Extract" :
                    if item["No of Objects"]>3 or item["No of Fields"]>30:
                        elements_not_following_prac_count += 1
                    else:
                        elements_following_prac_count += 1                       
                elif item["Type"] == "Transform":                    
                    if item["No of Fields"]>200:
                        elements_not_following_prac_count += 1
                    else:
                        elements_following_prac_count += 1        

                elif item["Type"] == "Load":
                    if item["No of Objects"]>3:
                        elements_not_following_prac_count += 1
                    else:
                        elements_following_prac_count += 1                                                                                           
                allActiveDataRaptorsRecords["records"] = final_result
                allActiveDataRaptorsRecords["size"] = len(final_result)
                allActiveDataRaptorsRecords["totalSize"] = len(final_result)
                allActiveDataRaptorsRecords['Elements following bad prac'] = elements_not_following_prac_count 
                allActiveDataRaptorsRecords['Elements following good prac'] = elements_following_prac_count

    except Exception as e:
        print(e)
    allActiveDataRaptorsRecords['methodname'] = "DRCore"+sf.session_id   
    await set_cache(allActiveDataRaptorsRecords) 
    return allActiveDataRaptorsRecords

@router.get("/{Id}")
def get_dataraptor_by_id(Id, get_current_user: dict = Depends(oauth2.get_current_user)):
    sf = Salesforce(instance_url="https://"+get_current_user['sf_instance'],
                    session_id=get_current_user['session_id'])
    get_dataraptor_element_by_id = "SELECT CreatedById, CreatedDate, DefaultValue, FilterDataType, FilterGroup, FilterOperator, FilterValue, FormulaConverted, FormulaExpression, FormulaResultPath, FormulaSequence, GlobalKey, Id, InputFieldName, InputObjectName, InputObjectQuerySequence, IsDeleted, IsDisabled, IsRequiredForUpsert, IsUpsertKey, LastModifiedById, LastModifiedDate, LastReferencedDate, LastViewedDate, LinkedFieldName, LinkedObjectSequence, LookupByFieldName, LookupObjectName, LookupReturnedFieldName, MigrationAttribute, MigrationCategory, MigrationGroup, MigrationKey, MigrationPattern, MigrationProcess, MigrationType, MigrationValue, Name, OmniDataTransformationId, OutputCreationSequence, OutputFieldFormat, OutputFieldName, OutputObjectName, SystemModstamp, TransformValueMappings FROM OmniDataTransformItem WHERE OmniDataTransformationId ='" + \
        Id+"'"
    try:
        specific_dataraptor = sf.query(get_dataraptor_element_by_id)
    except Exception as e:
        print(e)
    return specific_dataraptor

# The worker function
def splitTransaction(data):
    #print(f"here in pool data {data['resturl']}")
    pooled_data = []
    sf = Salesforce(instance_url=data['resturl'],
                        session_id=data['sid'])
    getDRIdQuery = "SELECT Id,InputFieldName,InputObjectName,Name,OmniDataTransformationId,OutputFieldName,OutputObjectName, LookupObjectName, LookupByFieldName, LinkedObjectSequence FROM OmniDataTransformItem WHERE OmniDataTransformationId='"  + data['Id'] + "'"    
    specificDRRecords = sf.query(getDRIdQuery)
    if specificDRRecords.get('records'):
        if data["Type"] == "Extract" or data["Type"] == "Turbo Extract" :
                #print(f"Extract {item['Type']}")
                no_of_object = 0
                no_of_fields = 0
                object_exist = []                    
                childObject = specificDRRecords.get('records')
                for y in childObject:
                    if y['InputObjectName'] is not None and y['InputObjectName'] not in object_exist:
                        object_exist.append(y['InputObjectName'])
                        no_of_object += 1
                    elif  y['InputObjectName'] is None and y['InputFieldName'] is not None:
                        no_of_fields += 1
                data["No of Objects"] = no_of_object
                data["No of Fields"] = no_of_fields                    
        elif data["Type"] == "Transform":
                #print(f"Transform {item['Type']}")
                no_of_object = 0
                no_of_fields = 0
                object_exist = []                    
                childObject = specificDRRecords.get('records')
                for y in childObject:
                    #print(f"Load child {y['OutputObjectName']}")
                    if y['OutputObjectName'] == 'json':
                        no_of_fields += 1
                data["No of Objects"] = no_of_object
                data["No of Fields"] = no_of_fields   

        elif data["Type"] == "Load":
                #print(f"Load {item['Type']}")
                no_of_object = 0
                no_of_fields = 0
                object_exist = []                    
                childObject = specificDRRecords.get('records')
                for y in childObject:
                    #print(f"Load child {y['OutputObjectName']}")
                    if (y['OutputObjectName'] is not None and y['OutputObjectName'] != 'Formula') and y['OutputObjectName'] not in object_exist :
                        object_exist.append(y['OutputObjectName'])
                        no_of_object += 1
                    if (y['OutputObjectName'] is not None and y['OutputObjectName'] != 'Formula') and y['OutputFieldName']is not None and y['LinkedObjectSequence']is None :
                        no_of_fields += 1                            
                data["No of Objects"] = no_of_object
                data["No of Fields"] = no_of_fields            
        #data[num]['ChildObjects'] = specificDRRecords.get('records')"""
        pooled_data.append(data)                                   
    return pooled_data

def chunks(lst, n):
    """Yield successive n-sized chunks from lst."""
    for i in range(0, len(lst), n):
        yield lst[i:i + n]
