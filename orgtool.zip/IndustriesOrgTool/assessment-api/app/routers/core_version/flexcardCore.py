from fastapi import FastAPI, Body, Response, status, HTTPException, Depends, APIRouter
from simple_salesforce import Salesforce, SalesforceLogin, SFType
from ... import oauth2
import json

router = APIRouter(
    prefix="/getflexcard",
    tags=['Flexcard']
)


@router.get("/")
def get_all_flexcard(get_current_user: dict = Depends(oauth2.get_current_user)):

    sf = Salesforce(instance_url="https://"+get_current_user['sf_instance'],
                    session_id=get_current_user['session_id'])
    get_all_flexcard_query = "SELECT AuthorName, CreatedDate, Id, Name, DataSourceConfig, VersionNumber FROM OmniUiCard WHERE IsActive = true"
    elements_not_following_prac_count = 0
    elements_following_prac_count = 0
    try:
        all_active_flexcard = sf.query(get_all_flexcard_query)
        if all_active_flexcard:
            for elm in all_active_flexcard['records']:
                print("Name: ", elm['Name'])
                dataSourceConfig = json.loads(elm['DataSourceConfig'])
                if "dataSource" in dataSourceConfig:
                    print(dataSourceConfig['dataSource']['type'])
                    if dataSourceConfig['dataSource']['type'] == "Query":
                        elements_not_following_prac_count += 1
                    else:
                        elements_following_prac_count += 1
                else:
                    print(dataSourceConfig['type'])
                    if dataSourceConfig['type'] == "Query":
                        elements_not_following_prac_count += 1
                    else:
                        elements_following_prac_count += 1
        all_active_flexcard['Elements following bad prac'] = elements_not_following_prac_count
        all_active_flexcard['Elements following good prac'] = elements_following_prac_count
    except Exception as e:
        print(e)
    return all_active_flexcard


@ router.get("/{Id}")
def get_flexcard_by_id(Id, get_current_user: dict = Depends(oauth2.get_current_user)):
    sf = Salesforce(instance_url="https://"+get_current_user['sf_instance'],
                    session_id=get_current_user['session_id'])
    get_flexcard_element_by_id = "SELECT AuthorName, CreatedDate, Id, Name, VersionNumber FROM OmniUiCard WHERE IsActive = true AND Id ='" + \
        Id+"'ORDER BY CreatedDate ASC NULLS FIRST"
    try:
        specific_flexcard = sf.query(get_flexcard_element_by_id)
    except Exception as e:
        print(e)
    return specific_flexcard
