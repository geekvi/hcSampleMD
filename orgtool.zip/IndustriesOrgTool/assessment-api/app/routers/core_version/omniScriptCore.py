from fastapi import FastAPI, Body, Response, status, HTTPException, Depends, APIRouter
from simple_salesforce import Salesforce, SalesforceLogin, SFType
from ... import oauth2
from multiprocessing.dummy import Pool as ThreadPool
from requests import *
from ...redis_function import get_cache, set_cache
import json

router = APIRouter(
    prefix="/getOmniScript",
    tags=['OmniScripts']
)


@router.get("/")
async def get_allomniscript(get_current_user: dict = Depends(oauth2.get_current_user)):
    sf = Salesforce(instance_url="https://"+get_current_user['sf_instance'],
                    session_id=get_current_user['session_id'])
    getAllomniscriptsQuery = "SELECT Id,ElementTypeComponentMapping,IsActive,IsOmniScriptEmbeddable,IsWebCompEnabled,Language,Name,SubType,Type FROM OmniProcess WHERE OmniProcessType = 'OmniScript' AND IsActive = true"
    getAllOmniProcessquery = "SELECT count(Id),OmniProcessId FROM OmniProcessElement WHERE IsActive = true Group by OmniProcessId"
    elements_not_following_prac_count = 0
    elements_following_prac_count = 0    
    try:
        cached_data = await get_cache("OSCore"+sf.session_id)
        #print(f"cached data {cached_data}")
        if cached_data is not None:
            allActiveOmniScriptsRecords = cached_data
        else:        
            allActiveOmniScriptsRecords = sf.query(getAllomniscriptsQuery)
            allActiveOmniProcessRecords = sf.query(getAllOmniProcessquery)

            for item in allActiveOmniScriptsRecords.get("records"):
                #print(f"item['id'] {item['Id']}")
                for child_item in allActiveOmniProcessRecords.get("records"):
                    #print(f"child_item['id'] {child_item['OmniProcessId']}")
                    if item["Id"] == child_item["OmniProcessId"]:
                        item["Number of Elements"] = child_item["expr0"]
                        if item["Number of Elements"]>200:
                            elements_not_following_prac_count += 1
                        else:
                            elements_following_prac_count += 1                         
            allActiveOmniScriptsRecords['Elements following bad prac'] = elements_not_following_prac_count 
            allActiveOmniScriptsRecords['Elements following good prac'] = elements_following_prac_count            
                
    except Exception as e:
        print(e)

    allActiveOmniScriptsRecords['methodname'] = "OSCore"+sf.session_id   
    await set_cache(allActiveOmniScriptsRecords) 

    return allActiveOmniScriptsRecords


@router.get("/{Id}")
def get_omniscript(Id, get_current_user: dict = Depends(oauth2.get_current_user)):
    sf = Salesforce(instance_url="https://"+get_current_user['sf_instance'],
                    session_id=get_current_user['session_id'])
    getomniscriptbyIdQuery = "SELECT Id,IsActive,IsOmniScriptEmbeddable,Level,Name,OmniProcessId,ParentElementId,ParentElementName,ParentElementType,SequenceNumber,Type FROM OmniProcessElement WHERE IsActive = true AND OmniProcessId = '" + \
        Id + "' ORDER BY Level ASC NULLS FIRST"
    try:
        specificOmniScriptRecord = sf.query(getomniscriptbyIdQuery)
    except Exception as e:
        print(e)
    return specificOmniScriptRecord

