from fastapi import FastAPI, Body, Response, status, HTTPException, Depends, APIRouter
from simple_salesforce import Salesforce, SalesforceLogin, SFType
from .. import oauth2

from ..redis_function import get_cache, set_cache

router = APIRouter(
    prefix="/getPlatformCache",
    tags=['Platformcache']
)


@router.get("/")
async def get_allapex(get_current_user: dict = Depends(oauth2.get_current_user)):
    sf = Salesforce(instance_url="https://"+get_current_user['sf_instance'],
                    session_id=get_current_user['session_id'])
    elements_not_following_prac_count = 0
    elements_following_prac_count = 0
    total_org_count = 0      
    try:
        cached_data = await get_cache("platformcache"+sf.session_id)   
        if cached_data is not None:
            get_platform_cache = cached_data
        else:          
            get_platform_cache = sf.toolingexecute(
                'query/?q=SELECT+AllocatedCapacity,CacheType,PlatformCachePartitionId,PlatformCachePartition.DeveloperName,PlatformCachePartition.IsDefaultPartition,PlatformCachePartition.NamespacePrefix+FROM+PlatformCachePartitionType+group+by+PlatformCachePartitionId,AllocatedCapacity,CacheType,PlatformCachePartition.DeveloperName,PlatformCachePartition.IsDefaultPartition,PlatformCachePartition.NamespacePrefix')
            for record in range(len(get_platform_cache.get("records"))):
                if get_platform_cache.get("records")[record]["CacheType"] == 'Organization' and get_platform_cache.get("records")[record]["AllocatedCapacity"] == 0:
                    elements_not_following_prac_count += 1
                if get_platform_cache.get("records")[record]["CacheType"] == 'Organization':
                    total_org_count += 1
                elements_following_prac_count =  total_org_count - elements_not_following_prac_count    
                get_platform_cache['Elements following bad prac'] = elements_not_following_prac_count 
                get_platform_cache['Elements following good prac'] = elements_following_prac_count
                get_platform_cache['totalSize'] = total_org_count    
        #allActiveApexRecords = sf.query_more("/services/data/v36.0/tooling/query?q=SELECT+AllocatedCapacity,CacheType,PlatformCachePartitionId,PlatformCachePartition.DeveloperName,PlatformCachePartition.IsDefaultPartition,PlatformCachePartition.NamespacePrefix+FROM+PlatformCachePartitionType+group+by+PlatformCachePartitionId,AllocatedCapacity,CacheType,PlatformCachePartition.DeveloperName,PlatformCachePartition.IsDefaultPartition,PlatformCachePartition.NamespacePrefix")
    
    except Exception as e:
        print(e)
    get_platform_cache['methodname'] = "platformcache"+sf.session_id   
    await set_cache(get_platform_cache)         
    return get_platform_cache
