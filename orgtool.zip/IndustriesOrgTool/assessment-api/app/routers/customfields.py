from fastapi import FastAPI, Body, Response, status, HTTPException, Depends, APIRouter
from simple_salesforce import Salesforce, SalesforceLogin, SFType
from .. import oauth2
from requests import *

from ..redis_function import get_cache, set_cache

router = APIRouter(
    prefix="/getCustomfield",
    tags=['customFields']
)


@router.get("/")
async def get_all_custom_fields(get_current_user: dict = Depends(oauth2.get_current_user)):
    sf = Salesforce(instance_url="https://"+get_current_user['sf_instance'],
                    session_id=get_current_user['session_id'])
    #get_all_custom_fields = "SELECT TableEnumOrId, count(DeveloperName), NamespacePrefix FROM CustomField WHERE NamespacePrefix = '' group by NamespacePrefix, TableEnumOrId "
    elements_not_following_prac_count = 0
    elements_following_prac_count = 0    
    try:
        cached_data = await get_cache("customfields"+sf.session_id)   
        if cached_data is not None:
            all_custom_fields = cached_data
        else:        
            all_custom_fields =  sf.toolingexecute(
                'query/?q=SELECT+TableEnumOrId,COUNT(DeveloperName),NamespacePrefix+FROM+CustomField+WHERE+NamespacePrefix = NULL+group by+NamespacePrefix,TableEnumOrId')
            for record in range(len(all_custom_fields.get("records"))):
                if all_custom_fields.get("records")[record]["expr0"]>30:
                    elements_not_following_prac_count += 1
                else:
                    elements_following_prac_count += 1     
                all_custom_fields['Elements following bad prac'] = elements_not_following_prac_count 
                all_custom_fields['Elements following good prac'] = elements_following_prac_count                            
            """ sfurl = "https://"+get_current_user['sf_instance']+"/services/data/v36.0/tooling/query?q=SELECT+TableEnumOrId,COUNT(DeveloperName),NamespacePrefix+FROM+CustomField+WHERE+NamespacePrefix = NULL+group by+NamespacePrefix,TableEnumOrId"
            response = get(sfurl, headers=sf.headers, cookies={'sid': sf.session_id})
            wf_metadata = response.json() """   
    except Exception as e:
        print(e)     
    all_custom_fields['methodname'] = "customfields"+sf.session_id   
    await set_cache(all_custom_fields) 

    return all_custom_fields

