from fastapi import FastAPI, Body, Response, status, HTTPException, Depends, APIRouter
from simple_salesforce import Salesforce, SalesforceLogin, SFType
from .. import oauth2
from requests import *
from ..redis_function import get_cache, set_cache

router = APIRouter(
    prefix="/getDataStorage",
    tags=['Datastorage']
)

""" @router.get("/")
def get_allapex(get_current_user: dict = Depends(oauth2.get_current_user)):
    sf = Salesforce(instance_url="https://"+get_current_user['sf_instance'],
                    session_id=get_current_user['session_id'])
    getAllapexQuery = "SELECT Id, LengthWithoutComments, Name, NamespacePrefix, Status, CreatedDate, LastModifiedDate FROM ApexClass WHERE NamespacePrefix = '' AND Status = 'Active' order by CreatedDate desc"
    try:
        allActiveApexRecords = sf.query(getAllapexQuery)
    except Exception as e:
        print(e)
    return allActiveApexRecords """


@router.get("/limits")
async def get_data_storage_limit(get_current_user: dict = Depends(oauth2.get_current_user)):
    sf = Salesforce(instance_url="https://"+get_current_user['sf_instance'],
                    session_id=get_current_user['session_id'])
    try:
        cached_data = await get_cache("datastorage"+sf.session_id)   
        if cached_data is not None:
            all_storage_limit = cached_data
        else:            
            sfurl = "https://"+get_current_user['sf_instance']+"/services/data/v45.0/limits"
            response = get(sfurl, headers=sf.headers, cookies={'sid': sf.session_id})
            all_storage_limit = response.json()
    except Exception as e:
        print(e)
    all_storage_limit['methodname'] = "datastorage"+sf.session_id   
    await set_cache(all_storage_limit) 
    return all_storage_limit

