from fastapi import FastAPI, Body, Response, status, HTTPException, Depends, APIRouter
from simple_salesforce import Salesforce, SalesforceLogin, SFType
from .. import oauth2
from ..redis_function import get_cache, set_cache
from requests import *

router = APIRouter(
    prefix="/getApexCoverage",
    tags=['Apex']
)


@router.get("/")
async def get_allapex(get_current_user: dict = Depends(oauth2.get_current_user)):
    sf = Salesforce(instance_url="https://"+get_current_user['sf_instance'],
                    session_id=get_current_user['session_id'])
    getAllapexQuery = "SELECT PercentCovered FROM ApexOrgWideCoverage"
    try:
        cached_data = await get_cache("apexcoverage"+sf.session_id)  
        #print(f"Cached data {cached_data}") 
        if cached_data is not None:
            allActiveApexRecords = cached_data
        else:          
            sfurl = "https://"+get_current_user['sf_instance']+"/services/data/v36.0/tooling/query?q=SELECT+PercentCovered+FROM+ApexOrgWideCoverage"
            response = get(sfurl, headers=sf.headers, cookies={'sid': sf.session_id})
            allActiveApexRecords = response.json()       
            #allActiveApexRecords = sf.query(getAllapexQuery)
    except Exception as e:
        print(e)
    allActiveApexRecords['methodname'] = "apexcoverage"+sf.session_id
    await set_cache(allActiveApexRecords)         
    return allActiveApexRecords


@router.get("/apexOrgWideCoverage")
def get_allapexorgwidecoverage(get_current_user: dict = Depends(oauth2.get_current_user)):
    sf = Salesforce(instance_url="https://"+get_current_user['sf_instance'],
                    session_id=get_current_user['session_id'])
    try:
        allApexOrgWideCoverage = sf.toolingexecute(
            'query/?q=SELECT+PercentCovered+FROM+ApexOrgWideCoverage')
    except Exception as e:
        print(e)
    return allApexOrgWideCoverage
