from fastapi import FastAPI, Body, Response, status, HTTPException, Depends, APIRouter
from simple_salesforce import Salesforce, SalesforceLogin, SFType
from multiprocessing.dummy import Pool as ThreadPool
from .. import oauth2
import json
from requests import *
from itertools import islice
from ..redis_function import get_cache, set_cache

router = APIRouter(
    prefix="/getProcessbuilder",
    tags=['Process Builder']
)


@router.get("/")
async def get_all_process_builder(get_current_user: dict = Depends(oauth2.get_current_user)):
    sf = Salesforce(instance_url="https://"+get_current_user['sf_instance'],
                    session_id=get_current_user['session_id'])
    final_result = []
    try:
        cached_data = await get_cache("ProcessBuilder"+sf.session_id)
        if cached_data is not None:
            all_wf_rules = cached_data
        else:        
            all_wf_rules = sf.toolingexecute(
                "query/?q=Select+Id,Description,MasterLabel,DefinitionId,ProcessType,ManageableState+From+Flow+WHERE+Status='Active'+AND+ProcessType!='AutoLaunchedFlow'+LIMIT+100+OFFSET+0")
            rest_url = "https://"+get_current_user['sf_instance']

            for record in range(len(all_wf_rules.get("records"))):
                all_wf_rules.get("records")[record]["resturl"]  =   "https://"+get_current_user['sf_instance']
                all_wf_rules.get("records")[record]["header"]  =  sf.headers
                all_wf_rules.get("records")[record]["sid"]  =  sf.session_id 
            #Splitting records into chunks of two to do threading 
            split_range = list(chunks(all_wf_rules.get('records'), 2))
            #Threading starts here 
            pool = ThreadPool(len(split_range))
            final_result = []
            test = pool.map(splitTransaction, split_range)

            pool.close()
            pool.join()             
            #print(f"test {test}")
            #The threaded data comes back in array of max 2 objects here since we are sending only 2 a time. We do some post processing to get the final count. 
            for i in range(len(test)):
                if len(test[i]) > 0:
                    for y in range(len(test[i])):
                        final_result.append(test[i][y])
            for item in final_result:
                item["Object type"] = item.get("Metadata")["processMetadataValues"][0]["value"]["stringValue"]
                del item["Metadata"]
                del item["header"]
                del item["resturl"]
                del item["sid"]


            all_wf_rules["records"] = final_result
            all_wf_rules["size"] = len(final_result)
            all_wf_rules["totalSize"] = len(final_result)
            all_wf_rules["records"] = test  

            #Threading ends here     
    except Exception as e:
        print(e)
    all_wf_rules['methodname'] = "ProcessBuilder"+sf.session_id   
    await set_cache(all_wf_rules)              
    return all_wf_rules

# The worker function
def splitTransaction(data):
    #print(f"here in pool data {data[0]}")
    pooled_data = []
    for num in range(len(data)):
        sfurl = data[num].get('resturl')+"/services/data/v44.0/tooling/query?q=Select+Metadata+From+Flow+Where+id='"+data[num].get('Id')+"'"
        response = get(sfurl, headers=data[num].get('header'), cookies={'sid': data[num].get('sid')})
        wf_metadata = response.json()
        #print(f"len(wf_metadata.get('records')) {len(wf_metadata['records'][0]['Metadata']['processMetadataValues'])}")
        if wf_metadata['records'] and wf_metadata['records'][0]['Metadata']['processMetadataValues'] \
            and wf_metadata['records'][0]['Metadata']['processMetadataValues'][0] and wf_metadata['records'][0]['Metadata']['processMetadataValues'][0]['value']:
            data[num].update(wf_metadata.get('records')[0])
            pooled_data.append(data[num])
    return pooled_data


def chunks(lst, n):
    """Yield successive n-sized chunks from lst."""
    for i in range(0, len(lst), n):
        yield lst[i:i + n]
