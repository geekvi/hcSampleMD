from fastapi import FastAPI, Body, Response, status, HTTPException, Depends, APIRouter
from simple_salesforce import Salesforce, SalesforceLogin, SFType
from simple_salesforce.exceptions import SalesforceMalformedRequest
from .. import schema, oauth2

router = APIRouter(
    prefix="/login",
    tags=['Login']
)


@router.post("/")
def login(user_cred: schema.userLogin):
    print(f"user_cred.useSecurityToken {user_cred.useSecurityToken}")
    if user_cred.useSecurityToken:
        sf = Salesforce(username=user_cred.email,
                        password=user_cred.password, security_token = user_cred.securityToken, domain=user_cred.domain)
    else:    
        sf = Salesforce(username=user_cred.email,
            password=user_cred.password, organizationId = user_cred.securityToken, domain=user_cred.domain)        
    print("sf_instance ", sf.sf_instance)
    print("session_id ", sf.session_id)
    access_token = oauth2.create_access_token(
        data={"session_id": sf.session_id, "sf_instance": sf.sf_instance})
    return {"access_token": access_token, "token_type": "bearer", "customer_name": user_cred.customerName}


@router.post("/internal/")
def loginInternal(user_cred: schema.internalUserLogin):
    sf = Salesforce(instance_url="https://"+user_cred.sf_instance,
                    session_id=user_cred.session_id)
    access_token = oauth2.create_access_token(
        data={"session_id": sf.session_id, "sf_instance": sf.sf_instance})
    return {"access_token": access_token, "token_type": "bearer"}
