from fastapi import FastAPI, Body, Response, status, HTTPException, Depends, APIRouter
from simple_salesforce import Salesforce, SalesforceLogin, SFType
from .. import oauth2

from ..redis_function import get_cache, set_cache

router = APIRouter(
    prefix="/getCustomObject",
    tags=['COF']
)


@router.get("/")
async def get_all_custom_objects(get_current_user: dict = Depends(oauth2.get_current_user)):
    sf = Salesforce(instance_url="https://"+get_current_user['sf_instance'],
                    session_id=get_current_user['session_id'])
    #get_all_custom_objs = "SELECT Id, DeveloperName, NamespacePrefix from CustomObject"
    try:
        cached_data = await get_cache("customobject"+sf.session_id)   
        if cached_data is not None:
            all_custom_objs = cached_data
        else:          
            all_custom_objs =  sf.toolingexecute(
                'query/?q=SELECT+Id,DeveloperName,NamespacePrefix+FROM+CustomObject')
    except Exception as e:
        print(e)
    all_custom_objs['methodname'] = "customobject"+sf.session_id   
    await set_cache(all_custom_objs)          
    return all_custom_objs

