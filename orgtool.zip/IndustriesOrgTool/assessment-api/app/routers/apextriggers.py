from fastapi import FastAPI, Body, Response, status, HTTPException, Depends, APIRouter
from simple_salesforce import Salesforce, SalesforceLogin, SFType
from .. import oauth2
from ..redis_function import get_cache, set_cache

router = APIRouter(
    prefix="/getApexTrigger",
    tags=['Tigger']
)


@router.get("/")
async def get_allapex(get_current_user: dict = Depends(oauth2.get_current_user)):
    sf = Salesforce(instance_url="https://"+get_current_user['sf_instance'],
                    session_id=get_current_user['session_id'])
    get_all_triggers = "SELECT Id, Name, TableEnumOrId, NamespacePrefix, LengthWithoutComments, Status, UsageAfterDelete, UsageAfterInsert, UsageAfterUndelete, UsageAfterUpdate, UsageBeforeDelete, UsageBeforeInsert, UsageBeforeUpdate, UsageIsBulk FROM ApexTrigger WHERE NamespacePrefix = ''"
    elements_not_following_prac_count = 0
    elements_following_prac_count = 0      
    try:
        cached_data = await get_cache("apextrigger"+sf.session_id)   
        if cached_data is not None:
            allActiveApexTriggers = cached_data
        else:          
            allActiveApexTriggers = sf.query(get_all_triggers)
            result = {}
            for item_counter in  allActiveApexTriggers['records']:
                if 'TableEnumOrId' in item_counter:
                    result[item_counter['TableEnumOrId']] = result.get(item_counter['TableEnumOrId'], 0) + 1
            #print(f"result {result}")
            for key, value in result.items():
                if value >= 2:
                    elements_not_following_prac_count += 1
            elements_following_prac_count = allActiveApexTriggers['totalSize'] - elements_not_following_prac_count

            allActiveApexTriggers['Elements following bad prac'] = elements_not_following_prac_count 
            allActiveApexTriggers['Elements following good prac'] = elements_following_prac_count  
    except Exception as e:
        print(e)
    allActiveApexTriggers['methodname'] = "apextrigger"+sf.session_id
    await set_cache(allActiveApexTriggers)    
    return allActiveApexTriggers
