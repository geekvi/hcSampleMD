from fastapi import FastAPI, Body, Response, status, HTTPException, Depends, APIRouter
from simple_salesforce import Salesforce, SalesforceLogin, SFType
import json
from ... import oauth2
from multiprocessing.dummy import Pool as ThreadPool
from requests import *
from ...redis_function import get_cache, set_cache

router = APIRouter(
    prefix="/getIntegrationProcedurePackage",
    tags=['IntegrationProcedure']
)


@router.get("/{nameSpace}")
async def get_allintegrationprocedure(nameSpace:str,get_current_user: dict = Depends(oauth2.get_current_user)):
    sf = Salesforce(instance_url="https://"+get_current_user['sf_instance'],
                    session_id=get_current_user['session_id'])
    getAllintegrationprocedureQuery = "SELECT count(Id), vlocity_" + nameSpace + "__OmniScriptId__c, vlocity_" + nameSpace + "__OmniScriptId__r.Name, vlocity_"+ \
    nameSpace + "__OmniScriptId__r.vlocity_" + nameSpace + "__Type__c, vlocity_" + nameSpace + "__OmniScriptId__r.vlocity_" + nameSpace + "__SubType__c FROM vlocity_" + \
    nameSpace + "__Element__c WHERE vlocity_" + nameSpace + "__OmniScriptId__r.vlocity_" + nameSpace + "__IsProcedure__c = true AND vlocity_" + nameSpace + "__OmniScriptId__r.vlocity_" + \
    nameSpace + "__IsActive__c = true group by vlocity_" + nameSpace + "__OmniScriptId__r.Name, vlocity_" + nameSpace + "__OmniScriptId__c, vlocity_" + \
    nameSpace + "__OmniScriptId__r.vlocity_" + nameSpace + "__Type__c, vlocity_" + nameSpace + "__OmniScriptId__r.vlocity_" + nameSpace + "__SubType__c"
    elements_not_following_prac_count = 0
    elements_following_prac_count = 0    
    try:
        cached_data = await get_cache("IPPackage"+sf.session_id)
        #print(f"cached data {cached_data}")
        if cached_data is not None:
            allActiveIntegrationProcedureRecords = cached_data
        else:
            allActiveIntegrationProcedureRecords = sf.query(
                getAllintegrationprocedureQuery)
            #print(allActiveIntegrationProcedureRecords.get("records"))
            for x in allActiveIntegrationProcedureRecords:
                if x == 'records':
                    for record in range(len(allActiveIntegrationProcedureRecords.get("records"))):
                        #print(f'allActiveIntegrationProcedureRecords.get("records")[record]["vlocity_"+nameSpace+"__OmniScriptId__c"] {allActiveIntegrationProcedureRecords.get("records")[record]["vlocity_"+nameSpace+"__OmniScriptId__c"]}')
                        """getintegrationprocedurebyIdQuery = "SELECT Name, vlocity_" + nameSpace + "__Active__c, vlocity_" + \
                        nameSpace + "__PropertySet__c, vlocity_" + nameSpace + "__ParentElementName__c, vlocity_" + \
                        nameSpace + "__Type__c FROM vlocity_" + nameSpace + "__Element__c WHERE vlocity_" + nameSpace + "__OmniScriptId__c = '" + allActiveIntegrationProcedureRecords.get("records")[record]["vlocity_"+nameSpace+"__OmniScriptId__c"]+ "'"   
                        specificIntegrationProcedureRecords = sf.query(getintegrationprocedurebyIdQuery)
                        print(f'specificIntegrationProcedureRecords {specificIntegrationProcedureRecords.get("records")[0]["vlocity_"+nameSpace+"__PropertySet__c"]}')"""
                        #responseActionPropConfig = json.loads(specificIntegrationProcedureRecords.get("records")[record]["vlocity_"+nameSpace+"__PropertySet__c"])
                        allActiveIntegrationProcedureRecords.get("records")[record]["attributes"]["type"] = "Package_IntegrationProcedure"
                        allActiveIntegrationProcedureRecords.get("records")[record]["Number of Elements"] = allActiveIntegrationProcedureRecords.get("records")[record]["expr0"]
                        del allActiveIntegrationProcedureRecords.get("records")[record]["expr0"]
                        allActiveIntegrationProcedureRecords.get("records")[record]["Type"] = allActiveIntegrationProcedureRecords.get("records")[record]["vlocity_"+nameSpace+"__Type__c"]
                        del allActiveIntegrationProcedureRecords.get("records")[record]["vlocity_cmt__Type__c"]
                        allActiveIntegrationProcedureRecords.get("records")[record]["Sub Type"] = allActiveIntegrationProcedureRecords.get("records")[record]["vlocity_"+nameSpace+"__SubType__c"]
                        del allActiveIntegrationProcedureRecords.get("records")[record]["vlocity_cmt__SubType__c"]
                        allActiveIntegrationProcedureRecords.get("records")[record]["Id"] = allActiveIntegrationProcedureRecords.get("records")[record]["vlocity_"+nameSpace+"__OmniScriptId__c"]
                        del allActiveIntegrationProcedureRecords.get("records")[record]["vlocity_cmt__OmniScriptId__c"]
                        allActiveIntegrationProcedureRecords.get("records")[record]["resturl"]  =   "https://"+get_current_user['sf_instance']
                        allActiveIntegrationProcedureRecords.get("records")[record]["header"]  =  sf.headers
                        allActiveIntegrationProcedureRecords.get("records")[record]["sid"]  =  sf.session_id    
                        allActiveIntegrationProcedureRecords.get("records")[record]["nameSpace"]  =  nameSpace                   

            #Splitting records into chunks of two to do threading 
            split_range = list(chunks( allActiveIntegrationProcedureRecords.get("records"), 1))

            
            #Threading starts here 
            pool = ThreadPool(len(split_range))
            final_result = []
            test = pool.map(splitTransaction, split_range)
            #print(f"test {test}")  
            #The threaded data comes back in array of max 2 objects here since we are sending only 2 a time. We do some post processing to get the final count. 
            for i in range(len(test)):
                if len(test[i]) > 0:
                    for y in range(len(test[i])):
                        final_result.append(test[i][y])
            for item in final_result:
                if item['Follows Good Practice'] == 'Yes':
                    elements_following_prac_count += 1
                else:
                    elements_not_following_prac_count += 1             
                del item["header"]
                del item["resturl"]
                del item["sid"]                       
                                                                                        
            allActiveIntegrationProcedureRecords["records"] = final_result
            allActiveIntegrationProcedureRecords["size"] = len(final_result)
            allActiveIntegrationProcedureRecords["totalSize"] = len(final_result)
            allActiveIntegrationProcedureRecords['Elements following bad prac'] = elements_not_following_prac_count 
            allActiveIntegrationProcedureRecords['Elements following good prac'] = elements_following_prac_count           
            pool.close()
            pool.join()   

    except Exception as e:
        print(e)
    allActiveIntegrationProcedureRecords['methodname'] = "IPPackage"+sf.session_id   
    await set_cache(allActiveIntegrationProcedureRecords)         
    return allActiveIntegrationProcedureRecords


#this is not tested. 
@router.get("/{nameSpace}/{Id}")
def get_integrationProcedure(nameSpace:str,Id:str, get_current_user: dict = Depends(oauth2.get_current_user)):
    sf = Salesforce(instance_url="https://"+get_current_user['sf_instance'],
                    session_id=get_current_user['session_id'])
    getintegrationprocedurebyIdQuery = "SELECT Name, vlocity_" + nameSpace + "__Active__c, vlocity_" + \
    nameSpace + "__PropertySet__c, vlocity_" + nameSpace + "__ParentElementName__c, vlocity_" + \
    nameSpace + "__Type__c FROM vlocity_" + nameSpace + "__Element__c WHERE vlocity_" + nameSpace + "__OmniScriptId__c = '" + Id+ "'"
    try:
        specificIntegrationProcedureRecords = sf.query(
            getintegrationprocedurebyIdQuery)
        for x in specificIntegrationProcedureRecords:
            if x == 'records':
                for record in range(len(specificIntegrationProcedureRecords.get("records"))):
                    if  specificIntegrationProcedureRecords.get("records")[record]["vlocity_"+nameSpace+"__Type__c"] == 'Response Action':      
                        responseActionPropConfig = json.loads(specificIntegrationProcedureRecords.get("records")[record]["vlocity_"+nameSpace+"__PropertySet__c"])
                        specificIntegrationProcedureRecords['returnFullDataJSON'] = responseActionPropConfig['returnFullDataJSON']
                        specificIntegrationProcedureRecords['returnOnlyAdditionalOutput'] = responseActionPropConfig['returnOnlyAdditionalOutput']
                        specificIntegrationProcedureRecords['sendJSONPath'] = responseActionPropConfig['sendJSONPath']
                        """specificIntegrationProcedureRecords['goodOrBad'] = "Bad Practice" if responseActionPropConfig['returnFullDataJSON'] else (
                            "Good Practice" if responseActionPropConfig['returnOnlyAdditionalOutput'] else ("Good Practice" if responseActionPropConfig['sendJSONPath'] else "Bad Practice"))"""   
                    
                        if 'returnFullDataJSON' in responseActionPropConfig:
                            specificIntegrationProcedureRecords['goodOrBad'] = "Bad Practice"
                        elif 'returnFullDataJSON' in responseActionPropConfig or 'returnOnlyAdditionalOutput' in responseActionPropConfig:
                            specificIntegrationProcedureRecords['goodOrBad'] = "Bad Practice"
                        else:
                            specificIntegrationProcedureRecords['goodOrBad'] = "Bad Practice"                    
                    del specificIntegrationProcedureRecords.get("records")[record]["vlocity_"+nameSpace+"__PropertySet__c"]
                    specificIntegrationProcedureRecords.get("records")[record]["Is Active"] = specificIntegrationProcedureRecords.get("records")[record]["vlocity_"+nameSpace+"__Active__c"]
                    del specificIntegrationProcedureRecords.get("records")[record]["vlocity_"+nameSpace+"__Active__c"]
                    specificIntegrationProcedureRecords.get("records")[record]["Parent Element"] = specificIntegrationProcedureRecords.get("records")[record]["vlocity_"+nameSpace+"__ParentElementName__c"]
                    del specificIntegrationProcedureRecords.get("records")[record]["vlocity_"+nameSpace+"__ParentElementName__c"] 
                    specificIntegrationProcedureRecords.get("records")[record]["Type"] = specificIntegrationProcedureRecords.get("records")[record]["vlocity_"+nameSpace+"__Type__c"]
                    del specificIntegrationProcedureRecords.get("records")[record]["vlocity_"+nameSpace+"__Type__c"]                                                                      
    except Exception as e:
        print(e)
    return specificIntegrationProcedureRecords
# The worker function
def splitTransaction(data):
    #print(f"here in pool data {data}")
    pooled_data = []
    for num in range(len(data)):
        nameSpace= data[num].get('nameSpace')
        sf = Salesforce(instance_url=data[num].get('resturl'),
                        session_id=data[num].get('sid'))
        getintegrationprocedurebyIdQuery = "SELECT Name, vlocity_"+ nameSpace + "__Active__c, vlocity_" + \
        nameSpace + "__PropertySet__c, vlocity_" + nameSpace + "__ParentElementName__c, vlocity_" + \
        nameSpace + "__Type__c FROM vlocity_" + nameSpace + "__Element__c WHERE vlocity_" + nameSpace + "__OmniScriptId__c = '" + data[num].get('Id')+ "'"
        specificIntegrationProcedureRecords = sf.query(getintegrationprocedurebyIdQuery)
        if len(specificIntegrationProcedureRecords.get('records'))>0:
            data[num]['Follows Good Practice'] = "No" 
            for elm in specificIntegrationProcedureRecords['records']:
                #print(f"elm['Type'] {elm['Type']}")
                if elm['vlocity_'+ nameSpace + '__Type__c'] == 'Response Action':            
                    responseActionPropConfig = json.loads(elm["vlocity_"+nameSpace+"__PropertySet__c"])
                    #print(f"responseActionPropConfig {responseActionPropConfig}")
                    if responseActionPropConfig['returnFullDataJSON']:
                        data[num]['Follows Good Practice'] = "No"
                    elif responseActionPropConfig['returnOnlyAdditionalOutput'] or len(responseActionPropConfig['sendJSONPath']) > 0:
                        data[num]['Follows Good Practice'] = "Yes"  
            pooled_data.append(data[num])                  
    return pooled_data

def chunks(lst, n):
    """Yield successive n-sized chunks from lst."""
    for i in range(0, len(lst), n):
        yield lst[i:i + n]

