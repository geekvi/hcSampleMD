from fastapi import FastAPI, Body, Response, status, HTTPException, Depends, APIRouter
from simple_salesforce import Salesforce, SalesforceLogin, SFType
from ... import oauth2

from ...redis_function import get_cache, set_cache
import asyncio

router = APIRouter(
    prefix="/getOmniScriptPackage",
    tags=['OmniScripts']
)


@router.get("/{nameSpace}")
async def get_allomniscript(nameSpace: str, get_current_user: dict = Depends(oauth2.get_current_user)):
    sf = Salesforce(instance_url="https://"+get_current_user['sf_instance'],
                    session_id=get_current_user['session_id'])
    get_all_namespace_OS = "SELECT count(Id), vlocity_" + nameSpace + "__OmniScriptId__c, vlocity_" + nameSpace + "__OmniScriptId__r.Name, vlocity_" + \
        nameSpace + "__OmniScriptId__r.vlocity_" + nameSpace + "__Type__c, vlocity_" + nameSpace + "__OmniScriptId__r.vlocity_" + \
        nameSpace + "__SubType__c FROM vlocity_" + nameSpace + "__Element__c WHERE vlocity_" + nameSpace + "__OmniScriptId__r.vlocity_" + \
        nameSpace + "__IsProcedure__c = false AND vlocity_" + nameSpace + "__OmniScriptId__r.vlocity_" + nameSpace + "__IsActive__c = true group by vlocity_" + \
        nameSpace + "__OmniScriptId__r.Name, vlocity_" + nameSpace + "__OmniScriptId__c, vlocity_" + nameSpace + "__OmniScriptId__r.vlocity_" + \
        nameSpace + "__Type__c, vlocity_" + nameSpace + \
        "__OmniScriptId__r.vlocity_" + nameSpace + "__SubType__c"
    elements_not_following_prac_count = 0
    elements_following_prac_count = 0
    try:
        cached_data = await get_cache("OSPackage"+sf.session_id)
        #print(f"cached data {cached_data}")
        if cached_data is not None:
            all_active_NS_OS = cached_data
        else:
            all_active_NS_OS = sf.query(get_all_namespace_OS)
            for record in range(len(all_active_NS_OS.get("records"))):
                all_active_NS_OS.get("records")[record]["attributes"]["type"] = "OmniProcessPackage"
                all_active_NS_OS.get("records")[record]["Number of Elements"] = all_active_NS_OS.get("records")[record]["expr0"]
                if all_active_NS_OS.get("records")[record]["expr0"]>200:
                    elements_not_following_prac_count += 1
                else:
                    elements_following_prac_count += 1

                del all_active_NS_OS.get("records")[record]["expr0"]
                all_active_NS_OS.get("records")[record]["Type"] = all_active_NS_OS.get("records")[record]["vlocity_" + nameSpace + "__Type__c"]
                del all_active_NS_OS.get("records")[record]["vlocity_" + nameSpace + "__Type__c"]  
                all_active_NS_OS.get("records")[record]["Sub Type"] = all_active_NS_OS.get("records")[record]["vlocity_" + nameSpace + "__SubType__c"]
                del all_active_NS_OS.get("records")[record]["vlocity_" + nameSpace + "__SubType__c"]                            
                all_active_NS_OS.get("records")[record]["Id"] = all_active_NS_OS.get("records")[record]["vlocity_" + nameSpace + "__OmniScriptId__c"] 
                del all_active_NS_OS.get("records")[record]["vlocity_" + nameSpace + "__OmniScriptId__c"]
            all_active_NS_OS['Elements following bad prac'] = elements_not_following_prac_count 
            all_active_NS_OS['Elements following good prac'] = elements_following_prac_count

    except Exception as e:
        print(e)
    all_active_NS_OS['methodname'] = "OSPackage"+sf.session_id   
    await set_cache(all_active_NS_OS)
       
    return all_active_NS_OS


@router.get("/{nameSpace}/{Id}")
def get_omniscript(nameSpace: str, Id: str, get_current_user: dict = Depends(oauth2.get_current_user)):
    sf = Salesforce(instance_url="https://"+get_current_user['sf_instance'],
                    session_id=get_current_user['session_id'])
    get_specific_NS_OS = "SELECT Name, vlocity_" + nameSpace + "__Active__c, vlocity_" + nameSpace + "__PropertySet__c, vlocity_" + \
        nameSpace + "__ParentElementName__c, vlocity_" + nameSpace + "__Type__c FROM vlocity_" + \
        nameSpace + "__Element__c WHERE vlocity_" + \
        nameSpace + "__OmniScriptId__c = '" + Id + "'"
    try:
        specificOmniScriptRecord = sf.query(get_specific_NS_OS)
        for record in range(len(specificOmniScriptRecord.get("records"))):
            specificOmniScriptRecord.get("records")[record]["Parent Name"] = specificOmniScriptRecord.get("records")[record]["vlocity_" + nameSpace + "__ParentElementName__c"] 
            del specificOmniScriptRecord.get("records")[record]["vlocity_" + nameSpace + "__ParentElementName__c"]        
            specificOmniScriptRecord.get("records")[record]["Type"] = specificOmniScriptRecord.get("records")[record]["vlocity_" + nameSpace + "__Type__c"] 
            del specificOmniScriptRecord.get("records")[record]["vlocity_" + nameSpace + "__Type__c"]
            del specificOmniScriptRecord.get("records")[record]["vlocity_" + nameSpace + "__PropertySet__c"]                                                                          

    except Exception as e:
        print(e)
    return specificOmniScriptRecord
