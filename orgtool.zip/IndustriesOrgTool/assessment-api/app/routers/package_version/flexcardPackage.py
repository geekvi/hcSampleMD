from fastapi import FastAPI, Body, Response, status, HTTPException, Depends, APIRouter
from simple_salesforce import Salesforce, SalesforceLogin, SFType
from ... import oauth2
from ...redis_function import get_cache, set_cache

router = APIRouter(
    prefix="/getflexcardPackage",
    tags=['Flexcard']
)


@router.get("/{nameSpace}")
async def get_all_flexcard(nameSpace:str,get_current_user: dict = Depends(oauth2.get_current_user)):
    
    sf = Salesforce(instance_url="https://"+get_current_user['sf_instance'],
                    session_id=get_current_user['session_id'])
    get_all_flexcard_query = "SELECT Id,Name,vlocity_" + nameSpace + "__Definition__c FROM vlocity_" + nameSpace + "__VlocityCard__c WHERE vlocity_" + nameSpace + "__Active__c = true and vlocity_" + nameSpace + "__Author__c != 'vlocity'"
    try:
        cached_data = await get_cache("FCPackage"+sf.session_id)
        #print(f"cached data {cached_data}")
        if cached_data is not None:
            all_active_flexcard = cached_data
        else:        
            all_active_flexcard = sf.query(get_all_flexcard_query)

            for record in range(len(all_active_flexcard.get("records"))):
                #all_active_flexcard.get("records")[record]["Type"] = all_active_flexcard.get("records")[record]["vlocity_" + nameSpace + "__Definition__c"]
                del all_active_flexcard.get("records")[record]["vlocity_" + nameSpace + "__Definition__c"]  
                  
    except Exception as e:
        print(e)
    all_active_flexcard['methodname'] = "FCPackage"+sf.session_id   
    await set_cache(all_active_flexcard)        
    return all_active_flexcard

@router.get("/{nameSpace}/{Id}")
def get_flexcard_by_id(nameSpace:str,Id:str, get_current_user: dict = Depends(oauth2.get_current_user)):
    sf = Salesforce(instance_url="https://"+get_current_user['sf_instance'],
                    session_id=get_current_user['session_id'])
    get_flexcard_element_by_id = "SELECT Id,Name,vlocity_" + nameSpace + " __Definition__c FROM vlocity_" + nameSpace + " __VlocityCard__c WHERE Id = '"+Id+"'AND vlocity_" + \
    nameSpace + " __Active__c = true and vlocity_" + nameSpace + " __Author__c != 'vlocity' ORDER BY CreatedDate ASC NULLS FIRST"
    try:
        specific_flexcard = sf.query(get_flexcard_element_by_id)
    except Exception as e:
        print(e)
    return specific_flexcard    
