from fastapi import FastAPI, Body, Response, status, HTTPException, Depends, APIRouter
from simple_salesforce import Salesforce, SalesforceLogin, SFType
from ... import oauth2

router = APIRouter(
    prefix="/getTemplates",
    tags=['Templates']
)

# All the Active Templates from the ORG


@router.get("/{nameSpace}")
def getalltemplates(nameSpace: str, get_current_user: dict = Depends(oauth2.get_current_user)):
    sf = Salesforce(instance_url="https://"+get_current_user['sf_instance'],
                    session_id=get_current_user['session_id'])
    getAllTemplates = "SELECT Id, Name, vlocity_" + nameSpace + "__Type__c FROM vlocity_" + nameSpace + \
        "__VlocityUITemplate__c WHERE vlocity_" + nameSpace + "__Active__c = true"
    try:
        allActiveTemplates = sf.query_all(getAllTemplates)
    except Exception as e:
        print(e)
    return allActiveTemplates


# Template information based on ID

@router.get("/{nameSpace}/{Id}")
def gettemplatebyId(nameSpace: str, Id: str, get_current_user: dict = Depends(oauth2.get_current_user)):
    sf = Salesforce(instance_url="https://"+get_current_user['sf_instance'],
                    session_id=get_current_user['session_id'])
    getTemplateById = "SELECT Id, Name, vlocity_" + nameSpace + "__HTML__c, vlocity_" + nameSpace + \
        "__CustomJavascript__c, vlocity_" + nameSpace + "__CSS__c FROM vlocity_" + nameSpace + \
        "__VlocityUITemplate__c WHERE Id='" + Id + "'"
    try:
        specificTemplateById = sf.query_all(getTemplateById)
        if specificTemplateById['records'] is not None:
            for elm in specificTemplateById['records']:
                test = elm['vlocity_cmt__HTML__c'].split("\n")
                test1 = elm['vlocity_cmt__CustomJavascript__c'].split("\n")
                print(test1)
    except Exception as e:
        print(e)
    return specificTemplateById['records']
