from fastapi import FastAPI, Body, Response, status, HTTPException, Depends, APIRouter
from simple_salesforce import Salesforce, SalesforceLogin, SFType
from ... import oauth2
import math
import json
from ...redis_function import get_cache, set_cache

router = APIRouter(
    prefix="/getdataRaptorPackage",
    tags=['DataRaptor']
)


@router.get("/{nameSpace}")
async def get_dataRaptor(nameSpace:str, get_current_user: dict = Depends(oauth2.get_current_user)):
    sf = Salesforce(instance_url="https://"+get_current_user['sf_instance'],
                    session_id=get_current_user['session_id'])
    
    final_data = []
    get_all_DR_query = "SELECT Id,Name,vlocity_" + nameSpace + "__DRMapName__c,vlocity_" + nameSpace + "__Type__c FROM vlocity_" + nameSpace + "__DRBundle__c ORDER BY vlocity_" + nameSpace + "__Type__c ASC"
    elements_not_following_prac_count = 0
    elements_following_prac_count = 0    
    try:
        cached_data = await get_cache("DRPackage"+sf.session_id)
        #print(f"cached data {cached_data}")
        if cached_data is not None:
            all_active_DR = cached_data
        else:
            all_active_DR = sf.query(get_all_DR_query)
            if not all_active_DR.get("done"):
                return
            
            get_all_DR_elements = "SELECT Id, Name, vlocity_" + nameSpace + "__DomainObjectAPIName__c, vlocity_" + nameSpace + "__DomainObjectFieldAPIName__c, vlocity_" + nameSpace + "__InterfaceObjectLookupOrder__c, vlocity_" + nameSpace + "__DomainObjectCreationOrder__c, vlocity_" + nameSpace + "__InterfaceFieldAPIName__c, vlocity_" + nameSpace + "__InterfaceObjectName__c FROM vlocity_" + nameSpace + "__DRMapItem__c ORDER BY Name ASC NULLS LAST"        
            all_elements = sf.query(get_all_DR_elements)

            print(f"All Elements {all_elements.get('done')}" )
            results = all_elements.get("records")
            is_done = all_elements.get("done")
            if len(results) == 0:
                return
            print(f"nextRecordsUrl {all_elements.get('nextRecordsUrl')}" )     
                
            while not is_done:
                if all_elements.get('done'):
                    is_done = True
                else:
                    all_elements = sf.query_more(all_elements.get('nextRecordsUrl'), True)
                    results.extend(all_elements.get("records"))

            final_data = sort_data(all_active_DR.get("records"), results, nameSpace)

            for item in final_data:
                if item['Good Practice']:
                    elements_following_prac_count += 1
                else:
                    elements_not_following_prac_count += 1
    
            all_active_DR["records"] = final_data
            all_active_DR["totalSize"] = len(final_data)
            all_active_DR['Elements following bad prac'] = elements_not_following_prac_count 
            all_active_DR['Elements following good prac'] = elements_following_prac_count                         
        
    except Exception as e:
        print(e)
    all_active_DR['methodname'] = "DRPackage"+sf.session_id           
    await set_cache(all_active_DR)

    return all_active_DR

def is_extract(nameSpace, dic):
    return dic.get("vlocity_" + nameSpace + "__Type__c") == "Extract" or dic.get("vlocity_" + nameSpace + "__Type__c")  == "Extract (JSON)" or dic.get("vlocity_" + nameSpace + "__Type__c")  == "Turbo Extract"

def is_load(nameSpace, dic):
    return dic.get("vlocity_" + nameSpace + "__Type__c") == "Load" or dic.get("vlocity_" + nameSpace + "__Type__c")  == "Load (JSON)"

def is_transform(nameSpace, dic):
    return dic.get("vlocity_" + nameSpace + "__Type__c") == "Transform"

def is_migration(nameSpace, dic):
    return dic.get("vlocity_" + nameSpace + "__Type__c") == "Migration"

def sort_data(all_dr_list, data, nameSpace):
    print('Sorting {} items', len(data))
    array_to_return = []
    for index, dic in enumerate(all_dr_list):         
        if is_extract(nameSpace, dic):
                result = count_object_fields(dic.get("vlocity_" + nameSpace + "__DRMapName__c"), data)           
                no_of_objects = []
                no_of_fields = []
                for new_index_list in result:
                    if (not new_index_list.get("vlocity_" + nameSpace + "__InterfaceObjectLookupOrder__c") in no_of_objects and new_index_list.get("vlocity_" + nameSpace + "__InterfaceObjectLookupOrder__c") != 0 and new_index_list.get("vlocity_" + nameSpace + "__InterfaceObjectLookupOrder__c") != None):
                        no_of_objects.append(new_index_list.get("vlocity_" + nameSpace + "__InterfaceObjectLookupOrder__c"))
                    if (new_index_list.get("vlocity_" + nameSpace + "__InterfaceObjectLookupOrder__c") == None and new_index_list.get("vlocity_" + nameSpace + "__DomainObjectCreationOrder__c") == 1):
                        no_of_fields.append(new_index_list.get("vlocity_" + nameSpace + "__InterfaceObjectLookupOrder__c"))   
                
                dic["No of Objects"] = len(no_of_objects)
                dic["No of Fields"] = len(no_of_fields)
                dic["Good Practice"] = True    
                if len(no_of_objects) > 3 or len(no_of_fields) > 30:
                    dic["Good Practice"] = False               
                del dic["vlocity_"+nameSpace +"__DRMapName__c"] 
                dic["Type"] =  dic["vlocity_"+nameSpace +"__Type__c"]
                del dic["vlocity_"+nameSpace +"__Type__c"]                  
                          
        elif is_load(nameSpace, dic):
                no_of_objects = []
                no_of_fields = []
                result = count_load_object_fields(dic.get("vlocity_" + nameSpace + "__DRMapName__c"), data, nameSpace)        
                for new_index_list in result:
                    if (not new_index_list.get("vlocity_" + nameSpace + "__DomainObjectCreationOrder__c") in no_of_objects and new_index_list.get("vlocity_" + nameSpace + "__DomainObjectCreationOrder__c") != 0):
                        no_of_objects.append(new_index_list.get("vlocity_" + nameSpace + "__DomainObjectCreationOrder__c"))
                dic["No of Objects"] = len(no_of_objects)
                dic["No of Fields"] = len(result)
                dic["Good Practice"] = True    
                if len(no_of_objects) > 3:
                    dic["Good Practice"] = False                  
                del dic["vlocity_"+nameSpace +"__DRMapName__c"] 
                dic["Type"] =  dic["vlocity_"+nameSpace +"__Type__c"]
                del dic["vlocity_"+nameSpace +"__Type__c"]                                   
        
        elif is_transform(nameSpace, dic):
                result = count_object_fields(dic.get("vlocity_" + nameSpace + "__DRMapName__c"), data)           
                dic["No of Objects"] = 0
                dic["No of Fields"] = len(result)
                dic["Good Practice"] = True    
                if len(no_of_fields) > 200:
                    dic["Good Practice"] = False                   
                del dic["vlocity_"+nameSpace +"__DRMapName__c"] 
                dic["Type"] =  dic["vlocity_"+nameSpace +"__Type__c"]
                del dic["vlocity_"+nameSpace +"__Type__c"]                             
        
        elif (is_migration(nameSpace, dic)):
            continue              
        else:
            dic["No of Objects"] = 0
            dic["No of Fields"] = 0
            dic["Good Practice"] = True                 
            del dic["vlocity_"+nameSpace +"__DRMapName__c"] 
            dic["Type"] =  dic["vlocity_"+nameSpace +"__Type__c"]
            del dic["vlocity_"+nameSpace +"__Type__c"]               

        array_to_return.append(dic)
    return array_to_return



def count_object_fields(name, map_data):
    return list(filter(lambda d: d['Name'] == name, map_data))

def count_load_object_fields(name, map_data, nameSpace):
    return list(filter(lambda d: d['Name'] == name and d['vlocity_'+nameSpace+'__InterfaceFieldAPIName__c'] != None, map_data)) 
 