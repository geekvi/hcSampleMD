from fastapi import FastAPI, Body, Response, status, HTTPException, Depends, APIRouter
from simple_salesforce import Salesforce, SalesforceLogin, SFType
from .. import oauth2
from ..redis_function import get_cache, set_cache

router = APIRouter(
    prefix="/getApex",
    tags=['Apex']
)


@router.get("/")
async def get_allapex(get_current_user: dict = Depends(oauth2.get_current_user)):
    sf = Salesforce(instance_url="https://"+get_current_user['sf_instance'],
                    session_id=get_current_user['session_id'])
    getAllapexQuery = "SELECT Id, LengthWithoutComments, Name, NamespacePrefix, Status, CreatedDate, LastModifiedDate FROM ApexClass WHERE NamespacePrefix = '' AND Status = 'Active' order by CreatedDate desc"
    elements_not_following_prac_count = 0
    elements_following_prac_count = 0      
    try:
        cached_data = await get_cache("apexclass"+sf.session_id)   
        if cached_data is not None:
            allActiveApexRecords = cached_data
        else:          
            allActiveApexRecords = sf.query(getAllapexQuery)

            for code_counter in  allActiveApexRecords['records']:
                if code_counter['LengthWithoutComments']>1000: 
                    print("here in if")
                    elements_not_following_prac_count+=1
                else:
                    print("here in else")
                    elements_following_prac_count+=1

            allActiveApexRecords['Elements following bad prac'] = elements_not_following_prac_count 
            allActiveApexRecords['Elements following good prac'] = elements_following_prac_count  
    except Exception as e:
        print(e)
    allActiveApexRecords['methodname'] = "apexclass"+sf.session_id
    await set_cache(allActiveApexRecords)         
    return allActiveApexRecords


