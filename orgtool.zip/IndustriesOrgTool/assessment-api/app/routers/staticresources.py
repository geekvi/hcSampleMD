from fastapi import FastAPI, Body, Response, status, HTTPException, Depends, APIRouter
from simple_salesforce import Salesforce, SalesforceLogin, SFType
from .. import oauth2
from ..redis_function import get_cache, set_cache

router = APIRouter(
    prefix="/getStaticResource",
    tags=['Staticresource']
)


@router.get("/")
async def get_allapex(get_current_user: dict = Depends(oauth2.get_current_user)):
    sf = Salesforce(instance_url="https://"+get_current_user['sf_instance'],
                    session_id=get_current_user['session_id'])
    getStaticResource = "SELECT SUM(BodyLength) FROM StaticResource"
    try:
        cached_data = await get_cache("staticresource"+sf.session_id)   
        if cached_data is not None:
            static_resource_size = cached_data
        else:         
            static_resource_size = sf.query(getStaticResource)
    except Exception as e:
        print(e)
    static_resource_size['methodname'] = "staticresource"+sf.session_id   
    await set_cache(static_resource_size)              
    return static_resource_size

