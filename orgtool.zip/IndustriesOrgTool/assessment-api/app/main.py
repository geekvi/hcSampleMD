from fastapi import FastAPI, Body, Response, status, HTTPException, Depends, APIRouter
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
from .routers import auth, apex, apextriggers, customobjects, datastorage, platformcache, processbuilder, staticresources, workflowrules, customfields, apexcodecoverage 
from .routers.core_version import omniScriptCore, dataRaptorCore, integrationProcedureCore, flexcardCore
from .routers.package_version import omniScriptPackage, dataRaptorPackage, integrationProcedurePackage, flexcardPackage, templatePackage
from .config import settings


app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.include_router(auth.router)

app.include_router(apex.router)
app.include_router(apextriggers.router)
app.include_router(apexcodecoverage.router)
app.include_router(customobjects.router)
app.include_router(datastorage.router)

app.include_router(platformcache.router)
app.include_router(processbuilder.router)
app.include_router(staticresources.router)
app.include_router(workflowrules.router)
app.include_router(customfields.router)

# core routes
app.include_router(omniScriptCore.router)
app.include_router(integrationProcedureCore.router)
app.include_router(dataRaptorCore.router)
app.include_router(flexcardCore.router)

# Packge routes
app.include_router(omniScriptPackage.router)
app.include_router(integrationProcedurePackage.router)
app.include_router(dataRaptorPackage.router)
app.include_router(flexcardPackage.router)
app.include_router(templatePackage.router)


@app.get("/")
async def root():
    return {"message": "Hello World this works!!!"}
