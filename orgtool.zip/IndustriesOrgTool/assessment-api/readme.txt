# Added upgrade for Redis from aioredis
#
This is an analyzer tool.

Pre-requsite:
1. Install python
2. Install pip3
3. Install virtual environment


In order to run the tool all you need to do is:
1. Open your terminal
2. Copy this commnad: pip3 install -r requirement.txt
3. Hit enter and it will install all the packages
4. Provision localcopy (image) of Redis note a port 
5. Create .env file with the following
    REDIS_URL=redis://localhost:6379
    ACCESS_TOKEN_EXPIRE_MINUTES = 60000
    REDIS_STRICT_SSL=false
    REDIS_TLS_URL=none
    algorithm=HS256
    secret_key=HotSummer2022

To run the app use below command:
source ../vOrgAn/bin/activate
uvicorn app.main:app --reload

note by default this app will run on port 8000; you can change the port by adding start up parameters
