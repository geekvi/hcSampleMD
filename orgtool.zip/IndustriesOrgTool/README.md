# IndustriesOrgTool
Simple Org Assessment tool
