import { createContext } from 'react';

export const nameSpaceContext = createContext();