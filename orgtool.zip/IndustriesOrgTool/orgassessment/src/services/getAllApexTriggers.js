import axios from "axios"

export async function getAllApexTriggers(page, options) {
	const ENDPOINT = process.env.REACT_APP_API_URL+"getApexTrigger";
	const token = localStorage.getItem('user-token')
	const authToken = "Bearer "+token;
	const { data } = await axios.get(ENDPOINT, {
		params: "",
		signal: "",
		headers: { Authorization: authToken, 'Access-Control-Allow-Origin': '*' },
	  });
	  return data;
}